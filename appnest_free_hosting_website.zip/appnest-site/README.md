# AppNest — Free app download website

This is a static HTML/CSS/JavaScript website. No build tools or paid software are required.

## Preview locally
Open `index.html` in a browser.

## Customize app listings
In `index.html`, find each `<article class="app"...>` block. Replace the sample app name, icon, description, category, platform and metadata with accurate information.

For a download button, change `data-url=""` to a trusted official store or developer download URL, for example:
`<button class="get" data-url="https://play.google.com/store/apps/details?id=YOUR_REAL_PACKAGE">Get app ↗</button>`
Use the real URL for the actual app. Do not leave placeholder links live.

## Free publishing with GitHub Pages
1. Sign in or create an account at https://github.com
2. Create a new public repository named `appnest-site` (or any name you prefer).
3. Upload `index.html` from this folder to the repository's root.
4. Open repository **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch `main` and folder `/ (root)`, then press **Save**.
7. Wait a few minutes. GitHub Pages will show your website URL in the Pages section, usually `https://YOUR-USERNAME.github.io/appnest-site/`.

## Before publishing
- Replace all sample app names and placeholder content.
- Add verified, official download URLs.
- Replace `hello@example.com` with a contact address you control.
- Add a privacy policy/contact page if your site collects user data.
- Never host apps you do not have permission to distribute. For APKs, provide safe, legitimate sources and clear version information.
